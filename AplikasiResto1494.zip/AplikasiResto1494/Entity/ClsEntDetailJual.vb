﻿Public Class ClsEntDetailJual

End Class
