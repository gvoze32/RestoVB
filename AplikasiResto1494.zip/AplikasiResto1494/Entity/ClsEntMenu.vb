﻿Public Class ClsEntMenu

End Class
