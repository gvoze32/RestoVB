﻿Public Class ClsEntKategori

End Class
